#include "aes.h"
#include "print.h"
#include "crng.h"
#define keyLength 32
#define NonceLength 8

extern BYTE IV[16] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

extern BYTE copyAES256Key = { 0, };


void GET_ALG_AES_HANDLE(BCRYPT_ALG_HANDLE* handle)
{
    NTSTATUS status = BCryptOpenAlgorithmProvider(
        handle,                
        BCRYPT_AES_ALGORITHM,
        NULL,
        0);


    if (!NT_SUCCESS(status))
    {
        printf("Error Code : %x \n BCryptOpenAlgorithmProvider fail\n", status);
        BCryptCloseAlgorithmProvider(handle, 0);
        return;
    }

    return;
}

void AES_Enc_TEST(BCRYPT_ALG_HANDLE ALG_HANDLE, BYTE* plaintext, DWORD filesize, BYTE* AES256Key, PBYTE ciphertext, DWORD ciphertextLength)
{
    NTSTATUS status = 0;
    BCRYPT_KEY_HANDLE KEY_HANDLE = NULL;        // AES Key Handle
    DWORD IVLength = 0;                         // IV Length
    DWORD BlockLength = 0;                      // Block Length
    DWORD bufferSize = 0;                       // Size of buffer

    BYTE iv[16] = { 0, };
    memcpy(iv, IV, 16);

    BYTE AES256KEY_CHANGE[keyLength] = { 0, };
    memcpy(AES256KEY_CHANGE, AES256Key, keyLength);

    //AES256KEY_CHANGE[24] = (BYTE)"2";
    //AES256KEY_CHANGE[25] = (BYTE)"0";
    //AES256KEY_CHANGE[26] = (BYTE)"2";
    //AES256KEY_CHANGE[27] = (BYTE)"4";
    //AES256KEY_CHANGE[28] = (BYTE)"_";
    //AES256KEY_CHANGE[29] = (BYTE)"F";
    //AES256KEY_CHANGE[30] = (BYTE)"a";
    //AES256KEY_CHANGE[31] = (BYTE)"S";

    std::cout << "change" << "\n";
    PRINT(AES256KEY_CHANGE, keyLength, PRINT_PLAINKEY);

    status = BCryptGenerateSymmetricKey(
        ALG_HANDLE,         // Algorithm Provider Handle
        &KEY_HANDLE,        // A pointer to Key Handle
        NULL,               //
        0,                  //
        AES256KEY_CHANGE,          // A pointer to a buffer that contains the key material
        keyLength,  // Size of the buffer that contains the key material
        0);                 // Flags
    if (!NT_SUCCESS(status))
    {
        printf("Error Code : %x \n BCryptGenerateSymmetricKey fail\n", status);
        BCryptDestroyKey(KEY_HANDLE);
        return;
    }

    status = BCryptSetProperty(
        ALG_HANDLE,                      // CNG HANDLE
        BCRYPT_CHAINING_MODE,            // Property name
        (PBYTE)BCRYPT_CHAIN_MODE_CBC,    // Buffer that contains new property value
        sizeof(BCRYPT_CHAIN_MODE_CBC),   // Size of the buffer that contains new propety value
        0);                              // Flags
    if (!NT_SUCCESS(status))
    {
        printf("Error Code : %x \n BCryptSetProperty fail\n", status);
        BCryptDestroyKey(KEY_HANDLE);
        return;
    }

    status = BCryptGetProperty(
        ALG_HANDLE,              // CNG HANDLE
        BCRYPT_BLOCK_LENGTH,     // Property name
        (PBYTE)&IVLength,       // Buffer which receives the property value
        sizeof(DWORD),           // Size of the buffer which receives the property value
        &bufferSize,             // Number of bytes that wer copied into the buffer
        0);                      // Flags
    if (!NT_SUCCESS(status))
    {
        printf("Error Code : %x \n BCryptGetProperty fail\n", status);
        BCryptDestroyKey(KEY_HANDLE);
        return;
    }

    status = BCryptEncrypt(                         // Calculate ciphertext length
        KEY_HANDLE,              // KEY HANDLE
        plaintext,               // Address of the buffer that contains the plain text
        filesize,       // Size of the buufer that contains the plain text
        NULL,                    // A pointer to padding info used with asymetric
        IV,                      // Address of the buffer that contains the Initial Vector
        IVLength,                // Size of the buffer that contains the Initial Vector
        NULL,                    // Address of the buffer that receives the ciphertext.
        0,                       // Size of the buffer that receives the ciphertext
        &ciphertextLength,      // Variable that receives number of bytes copied to ciphertext buffer
        BCRYPT_BLOCK_PADDING);   // Flags : Block Padding

    if (!NT_SUCCESS(status))
    {
        printf("Error Code : %x \n BCryptEncrypt(Calculate ciphertextLength) fail\n", status);
        BCryptDestroyKey(KEY_HANDLE);
        return;
    }
    else
    {
        ciphertext = (PBYTE)calloc(ciphertextLength, sizeof(BYTE));        // Free needed
        if (ciphertext == NULL)
        {
            printf("Memory Allocation(ciphertext) Fail...\n");
            BCryptDestroyKey(KEY_HANDLE);
            return;
        }
    }

    status = BCryptEncrypt(                         // Encrypt Data
        KEY_HANDLE,              // KEY HANDLE
        plaintext,               // Address of the buffer that contains the plain text
        filesize,       // Size of the buufer that contains the plain text
        NULL,                    // A pointer to padding info used with asymetric
        IV,                      // Address of the buffer that contains the Initial Vector
        IVLength,                // Size of the buffer that contains the Initial Vector
        ciphertext,              // Address of the buffer that receives the ciphertext.
        ciphertextLength,        // Size of the buffer that receives the ciphertext
        &bufferSize,             // Variable that receives number of bytes copied to ciphertext buffer
        BCRYPT_BLOCK_PADDING);   // Flags : Block Padding

    if (!NT_SUCCESS(status))
    {
        printf("Error Code : %x \n BCryptEncrypt(Encrypt Data) fail\n", status);
        BCryptDestroyKey(KEY_HANDLE);
        return;
    }

    printf("ciphertext1");
    PRINT(ciphertext, ciphertextLength, PRINT_CIPHERTEXT);

    BCryptDestroyKey(KEY_HANDLE);

    return;
}