#pragma once
extern BYTE AES256Key;
extern BYTE Nonce;
extern PBYTE cipherkey;
extern DWORD cipherkeyLength;
extern PBYTE ciphertext;
extern DWORD ciphertextLength;
extern BYTE IV[16];
extern BYTE AES256Key2[32];
extern BYTE savecipherkey[512];
extern BYTE copyNonce[8];
